-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- ホスト: 127.0.0.1
-- 生成日時: 2024-01-18 05:53:22
-- サーバのバージョン： 10.4.28-MariaDB
-- PHP のバージョン: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- データベース: `nameseisei`
--
CREATE DATABASE IF NOT EXISTS `nameseisei` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `nameseisei`;

-- --------------------------------------------------------

--
-- テーブルの構造 `cars`
--

CREATE TABLE `cars` (
  `company` varchar(100) NOT NULL,
  `car` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `cars`
--

INSERT INTO `cars` (`company`, `car`) VALUES
('カワサキ', 'ファンブラー'),
('三野', 'マグナム'),
('六車', 'イン'),
('型落ち', 'つついジーノ'),
('池田', 'いけDA');

-- --------------------------------------------------------

--
-- テーブルの構造 `favorites`
--

CREATE TABLE `favorites` (
  `favorite` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `historys`
--

CREATE TABLE `historys` (
  `history` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `people`
--

CREATE TABLE `people` (
  `family` varchar(100) NOT NULL,
  `last` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `people`
--

INSERT INTO `people` (`family`, `last`) VALUES
('川邉', '悠真'),
('椎名', '賢'),
('真龍王', '和希'),
('笹本', '純子'),
('筒井', '美咲');

-- --------------------------------------------------------

--
-- テーブルの構造 `pets`
--

CREATE TABLE `pets` (
  `pet_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `pets`
--

INSERT INTO `pets` (`pet_name`) VALUES
('むぐるまま'),
('影丸'),
('眞久'),
('豆助'),
('貞弘');

-- --------------------------------------------------------

--
-- テーブルの構造 `users`
--

CREATE TABLE `users` (
  `name` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `history` varchar(100) NOT NULL,
  `favorite` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- ダンプしたテーブルのインデックス
--

--
-- テーブルのインデックス `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`company`,`car`);

--
-- テーブルのインデックス `people`
--
ALTER TABLE `people`
  ADD PRIMARY KEY (`family`,`last`);

--
-- テーブルのインデックス `pets`
--
ALTER TABLE `pets`
  ADD PRIMARY KEY (`pet_name`);

--
-- テーブルのインデックス `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`name`,`pass`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
